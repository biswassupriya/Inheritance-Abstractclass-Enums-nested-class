public class NestedClass  {
    int cat = 2;
    String catOwnerName = "Supriya";

    public void setCatOwnerName(){
        System.out.println(catOwnerName);
    }

    public int getCat() {
        return cat;
    }

    public class InnerClass{
        int dog = 2;
        String dogOwnerName = "Supriya Mazumder";

        public void setDogOwnerName(){
            System.out.println(dogOwnerName);
        }

        public int getDog() {
            return dog;
        }
    }
}
