public abstract class Animal {
    public abstract void animalsounds();
    public abstract void animalColor();
    public int animalLegs = 4;

}