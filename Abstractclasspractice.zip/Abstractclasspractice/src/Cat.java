public class Cat extends Animal implements AnimalOwner {
    @Override
    public void animalColor() {
        System.out.println("Cat is black");
    }

    @Override
    public void animalsounds() {
        System.out.println("Cat says meow");
    }
     public int animalLegs(){
        return animalLegs;
     }

    @Override
    public void ownerfamily() {
        System.out.println("Owner Family Mazumder");
    }
}
