public class Main {
    public static void main(String[] args) {
        Cat c = new Cat();
        //c.animalLegs();
        System.out.println("The cat has" + c.animalLegs() + "Legs");
        c.animalColor();
        c.animalsounds();
        c.ownerfamily();

        Dog d = new Dog();
        System.out.println("The Dog has" + d.animalLegs() + "Legs");
        d.animalColor();
        d.animalsounds();
        d.ownerfamily();

        Animal a = new Cat();
        a.animalColor();
        a.animalsounds();
        System.out.println(a.animalLegs);

        Animal l = new Dog();
        l.animalsounds();
        l.animalColor();
        System.out.println(l.animalLegs);


        NestedClass n = new NestedClass();
        NestedClass.InnerClass In = n.new InnerClass();
        System.out.println(In.dogOwnerName + "has" + In.getDog() + "Dog" + "\n" + n.catOwnerName + " has" + "" + n.getCat() + "cat");
        System.out.println(In.getDog());
        System.out.println(n.getCat());
        /*can access outer class method is an advantage of nested class */

        AnimalOwner ao = new Cat();
        ao.ownerfamily();

        AnimalOwner an = new Dog();
        an.ownerfamily();
        /* interface can have reference  object for its own method */

        AnimalVoiceCategory vc = AnimalVoiceCategory.MEOW;
        System.out.println(vc + "is a Cat");

        AnimalVoiceCategory vc2 = AnimalVoiceCategory.MOO;

        for (AnimalVoiceCategory vc1 : AnimalVoiceCategory.values()) {
            System.out.println(vc1);
        }
        switch (vc2){
            case MEOW:
                System.out.println(" This ia a Cat");
                break;
            case ROAR:
                System.out.println("This ia a Tiger");
                break;
            case MOO:
                System.out.println("This ia a Cow");
                break;
            case WOOF:
                System.out.println("This ia a Dog");
                break;
            default:
                System.out.println("Animals are absent");

        }
    }
}
