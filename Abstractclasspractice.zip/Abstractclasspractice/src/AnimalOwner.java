public interface AnimalOwner {
    void ownerfamily();
}
