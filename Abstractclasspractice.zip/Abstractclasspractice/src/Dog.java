public class Dog extends Animal implements AnimalOwner{
    @Override
    public void animalsounds() {
        System.out.println("Dog says Woof");
    }

    @Override
    public void animalColor() {
        System.out.println("Dog is white");
    }
    public int animalLegs(){
        return animalLegs;
    }

    @Override
    public void ownerfamily() {
        System.out.println("Owner family is Mazumder Childrens");
    }
}