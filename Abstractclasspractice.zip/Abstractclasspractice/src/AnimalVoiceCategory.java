public enum AnimalVoiceCategory {
    MEOW,
    WOOF,
    MOO,
    ROAR
}
